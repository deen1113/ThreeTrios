package model;

public enum PlayerColor {
  RED, BLUE
}
