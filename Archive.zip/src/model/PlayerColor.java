package model;

/**
 * Represents the color of a player.
 */
public enum PlayerColor {
  RED, BLUE
}
