package model;

public enum GameState {
  NOT_STARTED, PLACING, BATTLE, FINISHED
}
