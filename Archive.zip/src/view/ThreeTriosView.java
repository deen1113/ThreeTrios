package view;

public class ThreeTriosView {
  private StringBuilder builder;
  private Appendable appendable;

  public String toString() {
    // Player: ----- need a way to get whose turn it is?
    return builder.toString();
  }
}