package view;

/**
 * This interface represents the view for the ThreeTrios game.
 */
public interface IThreeTriosJSwingView {
}
