package model;

import org.junit.Before;
import org.junit.Test;
import org.testng.Assert;

import java.io.FileNotFoundException;

public class TestThreeTriosModel {
  ThreeTriosModel model;


  // setup model for all tests
  @Before
  public void setupThreeTriosConstructor() throws FileNotFoundException {
    model = new ThreeTriosModel("/Users/llukach/IdeaProjects/CS2510/Homework/ThreeTrios/test/resources/testDeck9+1.txt", "/Users/llukach/IdeaProjects/CS2510/Homework/ThreeTrios/test/resources/grid3x3NoHoles.txt");
  }

  // check that the model starts with the correct number of cards in each hand
  @Test
  public void testStartingHand() {
    model.startGame();
    Assert.assertEquals(model.getRedHand().size(), 5);
    Assert.assertEquals(model.getBlueHand().size(), 5);
  }


  // check that game state gets correctly changed after each event
  @Test
  public void testCorrectlyChangeGameStateAfterAction() {
    Assert.assertEquals(model.getGameState(), GameState.NOT_STARTED);
    model.startGame();
    Assert.assertEquals(model.getGameState(), GameState.PLACING);
    model.placeCard(0, 1, 0, PlayerColor.RED);
    Assert.assertEquals(model.getGameState(), GameState.BATTLE);

  }

  @Test
  public void testPlaceCard() {
    model.startGame();
    Card card = model.getRedHand().get(0);
    String name = card.getName();
    model.placeCard(0, 1, 0, PlayerColor.RED);
    Assert.assertEquals(model.getRedHand().size(), 4);
    Assert.assertEquals(model.getBlueHand().size(), 5);
    Assert.assertEquals(model.getGrid().getCard(0, 1).getName(), name);
  }

  @Test
  public void testBattleFlipOne() {
    model.startGame();

    model.placeCard(0, 1, 0, PlayerColor.RED);

    model.battle(0, 1, PlayerColor.RED);

    model.placeCard(1, 1, 0, PlayerColor.BLUE);

    model.battle(1, 1, PlayerColor.BLUE);

    model.placeCard(1, 2, 0, PlayerColor.RED);

    model.battle(1, 2, PlayerColor.RED);

    model.placeCard(2, 2, 0, PlayerColor.BLUE);

    model.battle(2, 2, PlayerColor.BLUE);

    Assert.assertEquals(model.getGrid().getCard(1, 2).getColor(), PlayerColor.BLUE);
  }

  @Test
  public void testBattleChainFlipTwo() {
    model.startGame();

    model.placeCard(1, 2, 1, PlayerColor.RED);

    model.battle(1, 2, PlayerColor.RED);

    model.placeCard(1, 1, 0, PlayerColor.BLUE);

    model.battle(1, 1, PlayerColor.BLUE);
    Assert.assertEquals(model.getGrid().getCard(1, 1).getColor(), PlayerColor.BLUE);
    Assert.assertEquals(model.getGrid().getCard(1, 2).getColor(), PlayerColor.BLUE);


    model.placeCard(1, 0, 1, PlayerColor.RED);

    model.battle(1, 0, PlayerColor.RED);


    Assert.assertEquals(model.getGrid().getCard(1, 0).getColor(), PlayerColor.RED);
    Assert.assertEquals(model.getGrid().getCard(1, 1).getColor(), PlayerColor.RED);
    Assert.assertEquals(model.getGrid().getCard(1, 2).getColor(), PlayerColor.RED);
  }

  
}