package view;


public interface IThreeTriosJSwingView {
}
